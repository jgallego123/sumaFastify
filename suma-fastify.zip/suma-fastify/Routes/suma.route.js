async function route(fastify, options) {
    fastify.get('/:numberOne/:numberTwo', async(req, res) => {
        const num1 = parseInt(req.params.numberOne);
        const num2 = parseInt(req.params.numberTwo);
        const sum = num1 + num2;

        res.send({
            numero1:  num1,
            numero2:  num2,
            resultadoSuma: sum
        });
    });
}

module.exports = route;